#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fill_spec_prices.py — заполнение колонки цен спецификации из справочного файла.

Команды:
  fill    заполнить цены и сохранить НОВЫЙ файл (оригинал не трогается)
  verify  проверить заполненный файл против справочника и оригинала

Примеры:
  python fill_spec_prices.py fill "spec.xlsx" "ref.xlsx"
  python fill_spec_prices.py fill "spec.xlsx" "ref.xlsx" --out "out.xlsx"
  python fill_spec_prices.py verify "out.xlsx" "ref.xlsx" --orig "spec.xlsx"

Параметры по умолчанию — структура типового ВОР:
  спецификация:  тип строки в A, наименование в C, цена в H;
                 заполняются только типы из --row-types (по умолчанию материал,материалы)
  справочник:    наименование в B, цена в H

Правила (по умолчанию):
  - строки «работа» и прочие типы НЕ заполняются;
  - цена '-'/'—'/'–' в справочнике -> ячейка цены остаётся пустой, строка заливается
    цветом --dash-color (FFC7CE);
  - строки без позиции в справочнике -> пустые, без заливки;
  - цены копируются как числа без округлений;
  - формулы и объединения ячеек сохраняются (data_only=False),
    ставится fullCalcOnLoad=True.
"""
import argparse
import os
import sys

import openpyxl
from openpyxl.styles import PatternFill

DASH = {"-", "—", "–"}


def norm(s):
    if s is None:
        return ""
    return " ".join(str(s).split()).lower().replace("ё", "е")


def parse_col(arg):
    """'A' -> 1, 'H' -> 8; цифры оставить как есть."""
    arg = str(arg).strip()
    if arg.isdigit():
        return int(arg)
    n = 0
    for ch in arg.upper():
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n


def build_ref(ref_path, ref_name_col, ref_price_col):
    wb = openpyxl.load_workbook(ref_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    ref = {}
    for r in range(2, ws.max_row + 1):
        name = ws.cell(row=r, column=ref_name_col).value
        if name is None or str(name).strip() == "":
            continue
        key = norm(name)
        if key not in ref:  # первый дубль выигрывает
            ref[key] = ws.cell(row=r, column=ref_price_col).value
    return ref


def default_out(spec_path):
    base, ext = os.path.splitext(spec_path)
    return base + "_с_ценами" + (ext or ".xlsx")


def cmd_fill(args):
    ref = build_ref(args.ref, args.ref_name_col, args.ref_price_col)
    row_types = {t.strip().lower() for t in args.row_types.split(",") if t.strip()}

    wb = openpyxl.load_workbook(args.spec, data_only=False)
    ws = wb[wb.sheetnames[0]]

    red_fill = PatternFill(
        start_color="FF" + args.dash_color.upper(),
        end_color="FF" + args.dash_color.upper(),
        fill_type="solid",
    )
    # не-якорные ячейки объединений (заливка по ним не отображается)
    non_anchor = set()
    for m in ws.merged_cells.ranges:
        for row in range(m.min_row, m.max_row + 1):
            for col in range(m.min_col, m.max_col + 1):
                if (row, col) != (m.min_row, m.min_col):
                    non_anchor.add((row, col))

    stats = {"numeric": 0, "dash": 0, "no_ref": 0, "other_skipped": 0}
    dash_rows, no_ref_rows = [], []

    for r in range(args.start_row, ws.max_row + 1):
        a = ws.cell(row=r, column=args.type_col).value
        c = ws.cell(row=r, column=args.name_col).value
        if c is None or str(c).strip() == "":
            continue
        type_key = norm(a)
        if type_key not in row_types:
            stats["other_skipped"] += 1
            continue
        key = norm(c)
        if key not in ref:
            stats["no_ref"] += 1
            no_ref_rows.append(r)
            continue
        price = ref[key]
        if isinstance(price, str) and price.strip() in DASH:
            stats["dash"] += 1
            dash_rows.append(r)
            for col in range(1, 26):  # A..Y
                if (r, col) in non_anchor:
                    continue
                ws.cell(row=r, column=col).fill = red_fill
            continue
        try:
            num = float(str(price).replace(",", "").replace(" ", ""))
        except (TypeError, ValueError):
            stats["no_ref"] += 1
            no_ref_rows.append(r)
            continue
        ws.cell(row=r, column=args.price_col).value = num
        stats["numeric"] += 1

    out = args.out or default_out(args.spec)
    wb.calculation.fullCalcOnLoad = True
    wb.save(out)
    print(f"Saved: {out}")
    print(f"STATS: {stats}")
    print(f"DASH_ROWS ({len(dash_rows)}): {dash_rows}")
    print(f"NO_REF ({len(no_ref_rows)}): {no_ref_rows}")


def cmd_verify(args):
    ref = build_ref(args.ref, args.ref_name_col, args.ref_price_col)
    row_types = {t.strip().lower() for t in args.row_types.split(",") if t.strip()}

    wb = openpyxl.load_workbook(args.out, data_only=False)
    ws = wb[wb.sheetnames[0]]

    errors = []
    numeric = dash = no_ref = 0
    other_filled = []
    dash_red_ok = dash_red_bad = 0

    for r in range(args.start_row, ws.max_row + 1):
        a = ws.cell(row=r, column=args.type_col).value
        c = ws.cell(row=r, column=args.name_col).value
        h = ws.cell(row=r, column=args.price_col).value
        if c is None or str(c).strip() == "":
            continue
        type_key = norm(a)
        key = norm(c)
        if type_key in row_types:
            if isinstance(h, (int, float)):
                numeric += 1
                if key not in ref:
                    errors.append(f"R{r}: цена {h} но позиции нет в справочнике")
                else:
                    rp = ref[key]
                    if isinstance(rp, str) or abs(float(rp) - float(h)) > 1e-9:
                        errors.append(f"R{r}: цена {h} != справочник {rp!r}")
            elif key in ref and not isinstance(ref[key], str):
                errors.append(f"R{r}: {str(c)[:50]} цена не проставлена, в справочнике {ref[key]!r}")
            elif key in ref:  # цена '-' в справочнике
                dash += 1
                fill = ws.cell(row=r, column=args.name_col).fill
                if fill is not None and fill.fill_type == "solid" and str(fill.start_color.rgb).endswith(args.dash_color.upper()):
                    dash_red_ok += 1
                else:
                    dash_red_bad += 1
                    errors.append(f"R{r}: цена '-' но строка не залита {args.dash_color}")
            else:
                no_ref += 1
        else:
            # «прочие» строки (работа и т.п.): ловим только числовые цены,
            # пропуская шапку и служебные строки (тип-число или цена-текст)
            if isinstance(h, (int, float)) and not str(type_key).replace(".", "").isdigit():
                other_filled.append((r, str(c).strip(), h))

    print(f"Материал-строк с ценой: {numeric}")
    print(f"С ценой '-' (красных {dash_red_ok}/{dash}): {dash}")
    print(f"Без позиции в справочнике: {no_ref}")
    print(f"Прочих строк (работа и т.п.) с заполненной ценой: {len(other_filled)}")
    for r, name, h in other_filled[:10]:
        print(f"   R{r}: {name[:60]!r} H={h!r}")
    print(f"Ошибок сверки: {len(errors)}")
    for e in errors[:30]:
        print("   ", e)

    if args.orig:
        wb_o = openpyxl.load_workbook(args.orig, data_only=False)
        ws_o = wb_o[wb_o.sheetnames[0]]
        m_o = sorted(str(m) for m in ws_o.merged_cells.ranges)
        m_n = sorted(str(m) for m in ws.merged_cells.ranges)
        dim_ok = ws.dimensions == ws_o.dimensions
        merges_ok = m_o == m_n
        print(f"Структура: размер {'OK' if dim_ok else 'ОТЛИЧИЕ! ' + ws.dimensions + ' vs ' + ws_o.dimensions}, "
              f"объединения {'OK' if merges_ok else 'ОТЛИЧИЕ! ' + str(len(m_o)) + ' vs ' + str(len(m_n))}")
        if not merges_ok:
            print("  только в оригинале:", [x for x in m_o if x not in m_n][:10])
            print("  только в новом:", [x for x in m_n if x not in m_o][:10])
    print(f"fullCalcOnLoad: {wb.calculation.fullCalcOnLoad}")

    if errors or other_filled:
        sys.exit(1)


def main():
    p = argparse.ArgumentParser(description="Заполнение цен спецификации из справочника")
    sub = p.add_subparsers(dest="cmd", required=True)

    pf = sub.add_parser("fill", help="заполнить цены и сохранить новый файл")
    pf.add_argument("spec", help="спецификация (ВОР)")
    pf.add_argument("ref", help="справочник с ценами")
    pf.add_argument("--out", help="имя нового файла (по умолчанию <spec>_с_ценами.xlsx)")
    add_common(pf)
    pf.set_defaults(func=cmd_fill)

    pv = sub.add_parser("verify", help="проверить заполненный файл")
    pv.add_argument("out", help="заполненный файл")
    pv.add_argument("ref", help="справочник с ценами")
    pv.add_argument("--orig", help="оригинал спецификации (для сравнения структуры)")
    add_common(pv)
    pv.set_defaults(func=cmd_verify)

    args = p.parse_args()
    args.func(args)


def add_common(parser):
    parser.add_argument("--type-col", default="A", type=parse_col, help="колонка типа строки в спецификации (default A)")
    parser.add_argument("--name-col", default="C", type=parse_col, help="колонка наименования в спецификации (default C)")
    parser.add_argument("--price-col", default="H", type=parse_col, help="колонка цены в спецификации (default H)")
    parser.add_argument("--row-types", default="материал,материалы",
                        help="типы строк, которые заполняются (default 'материал,материалы')")
    parser.add_argument("--ref-name-col", default="B", type=parse_col, help="колонка наименования в справочнике (default B)")
    parser.add_argument("--ref-price-col", default="H", type=parse_col, help="колонка цены в справочнике (default H)")
    parser.add_argument("--dash-color", default="FFC7CE", help="цвет заливки строк с ценой '-' (default FFC7CE)")
    parser.add_argument("--start-row", type=int, default=2, help="первая строка данных (default 2)")


if __name__ == "__main__":
    main()
