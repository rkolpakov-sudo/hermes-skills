#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_spec.py — PDF-спецификация (ВК/СО/ОВ) -> CSV + JSON + лог.

Использование:
    python extract_spec.py <input.pdf> [--out-dir DIR] [--sep ;]

Вывод:
    <out>/spec_<base>.csv       — финальный CSV (utf-8-sig, sep по аргументу)
    <out>/spec_<base>_rows.json — структурированные строки (item/header/component)
    <out>/spec_<base>_log.json  — журнал классификации/слияний/очистки

Логика:
  * Извлечение строк — pymupdf find_tables().extract() (корректен и на повёрнутых листах).
  * Логические колонки (9) маппятся ПО СТРАНИЦЕ по тексту заголовка:
    поз, name, type, code, supplier, unit, qty, mass, note.
  * Классификация строк:
    - есть qty              -> item (позиция)
    - без qty + заголовок   -> header (раздел, отдельная строка)
    - без qty + есть type   -> component (состав «компл:», отдельная строка)
    - без qty, без type     -> continuation -> сливается с предыдущей позицией
  * Очистка: разорванные слова (SPLITS), артефакт Ø (токен-правило),
    «х»-разделитель, «В1 .3», склейка ГОСТ/ТУ-номеров.
"""
import argparse, json, os, re, csv, sys
import pymupdf

# ---------------------------------------------------------------- настройки
# Реальные диаметры труб (для токен-правила Ø): 6/ф -> Ø только перед ними
DIAMETERS = {15, 20, 25, 32, 40, 50, 65, 80, 100, 110, 125, 150, 160, 200, 219,
             250, 300, 400, 500, 1000}

# Разорванные слова (артефакты шрифта): (испорчено, правильно).
# Расширяйте под конкретный документ — диагностика в отчёте подскажет.
SPLITS = [
    ('во д огазопров о д ная', 'водогазопроводная'),
    ('оцинков анная', 'оцинкованная'),
    ('электрос варная', 'электросварная'),
    ('прямошов ная', 'прямошовная'),
    ('Гофриров анная', 'Гофрированная'),
    ('Ги б кая', 'Гибкая'),
    ('присоед инения', 'присоединения'),
    ('Патруб ок', 'Патрубок'),
    ('переход ной', 'переходной'),
    ('Трой ник', 'Тройник'),
    ('О т во д', 'Отвод'),
    ('В од омерный', 'Водомерный'),
    ('К ов ер', 'Ковёр'),
    ('гиб ком', 'гибком'),
    ('Труб а', 'Труба'),
    ('на гиб ком', 'на гибком'),
]

# Поставщики с артефактами
SUPPLIER_FIX = {
    'Ekopl astik': 'Ekoplastik',
    'Агпа йп': 'Агпайп',
}

# Префиксы/шаблоны заголовков разделов (ВК + ОВ)
HEADER_PREFIXES = [
    'Трубы и изоляция', 'Трубопроводы и изоляция', 'Оборудование и арматура',
    'Оборудование, фитинги', 'Сантехническое оборудование', 'Гидравлическое испытание',
    'Водопровод', 'Канализация', 'Водомерные узлы', 'Окраска трубопроводов',
    # ОВ (отопление и вентиляция)
    'Отопление', 'Фасонные изделия', 'Теплоснабжение приточных установок',
    'Общеобменная вентиляция', 'Противодымная вентиляция', 'Холодоснабжение',
    'Кондиционирование', 'Крепежный материал', 'Вентиляция и противодымная защита',
    'Хозяйственно-питьевой водопровод', 'Противопожарный водопровод',
    'Горячее водоснабжение', 'Резервное горячее водоснабжение',
]
# Заголовок раздела = «<система> [ВТК]<цифры>» внутри строки
# (проверено: НЕ ловит «Водомерный узел В1.3» — там нет слов водопровод/водоснабжение/канализация).
HEADER_RE = re.compile(r'(водопровод|водоснабжение|канализация)\s*[ВТК]\d')

# ---------------------------------------------------------------- очистка
def _fix_split(s, a, b):
    """Склеить разорванное слово, сохранив РЕГУЛЯРНЫЙ регистр исходного текста.

    b — только канонический вариант (для отладки/лога). Фактический результат
    = исходный текст без пробелов, поэтому 'гофриров анная'→'гофрированная',
    а 'Гофриров анная'→'Гофрированная'.
    """
    if a.lower() not in s.lower():
        return s
    pat = re.compile(re.escape(a), re.IGNORECASE)
    return pat.sub(lambda m: m.group(0).replace(' ', ''), s)

def is_diam(token: str) -> bool:
    m = re.match(r'^(\d+)', token)
    return bool(m) and int(m.group(1)) in DIAMETERS

def clean_text(s: str) -> str:
    """Базовая очистка для type/supplier/note."""
    if not s:
        return ''
    for a, b in SUPPLIER_FIX.items():
        s = s.replace(a, b)
    for a, b in SPLITS:
        s = _fix_split(s, a, b)
    s = re.sub(r'\s+', ' ', s).strip()
    s = re.sub(r'(ТУ|ГОСТ)\s+-', r'\1-', s)     # «ТУ -2248» -> «ТУ-2248»
    s = re.sub(r'(-)\s+(\d)', r'\1\2', s)       # «2248- 043» -> «2248-043»
    s = re.sub(r'(\d)\s+(-)', r'\1\2', s)       # «2248 -043» -> «2248-043»
    s = s.replace(' ,', ',')
    s = re.sub(r'(\d),\s+(\d)', r'\1,\2', s)
    s = re.sub(r'(\d)\s+(\.\d)', r'\1\2', s)          # "В1 .3" -> "В1.3"
    return re.sub(r'\s+', ' ', s).strip()

def clean_name(s: str) -> str:
    if not s:
        return ''
    s = clean_text(s)
    # Ведущий дефис «- кран шаровой Ду20» — маркер ВЛОЖЕННОСТИ (состав группы «Узел ввода…»),
    # а не часть наименования. Убираем его: иначе Excel читает ячейку как формулу → #ИМЯ?.
    s = re.sub(r'^-\s*', '', s)
    s = s.replace('м .', 'м.').replace('Д =', 'Д=')
    s = re.sub(r'= (\d)', r'=\1', s)
    s = re.sub(r'(\d)х\s+(\d)', r'\1х\2', s)          # «х» только между цифрами
    # --- артефакт Ø: ведущий токен 6/ф перед реальным диаметром ---
    toks = s.split(); out = []; i = 0
    while i < len(toks):
        t = toks[i]
        if t == '6' and i + 1 < len(toks) and is_diam(toks[i + 1]):
            out.append('Ø' + re.sub(r'\s', '', toks[i + 1])); i += 2; continue
        # «6150х4,5» -> «Ø150х4,5»: 6 + диаметр + «х» + толщина (<100).
        # НЕ трогать «650x400» (размер воздуховода 650×400 — после 6 идёт 50, затем x400).
        m6 = re.match(r'^6(\d+)[хx]([\d.,]+)$', t)
        if m6 and m6.group(1) in DIAMETERS:
            thick = m6.group(2).replace(',', '.')
            if float(thick) < 100:
                out.append('Ø' + m6.group(1) + 'х' + m6.group(2)); i += 1; continue
        if t.startswith('ф') and re.match(r'ф\d', t) and is_diam(t[1:]):
            out.append('Ø' + t[1:]); i += 1; continue
        out.append(t); i += 1
    s2 = re.sub(r'Ø\s+(\d)', r'Ø\1', ' '.join(out)).replace('∅', 'Ø')
    return re.sub(r'\s+', ' ', s2).strip()

def is_header(name: str) -> bool:
    if any(name == p or name.startswith(p) for p in HEADER_PREFIXES):
        return True
    return bool(HEADER_RE.search(name)) and len(name) < 75

# ---------------------------------------------------------------- извлечение
def map_columns(header_row) -> dict:
    """Маппинг 9 логических колонок по тексту заголовка (индексы физических ячеек).
    Поддерживает ВК-шаблон («Поз.», «Код продукции», «Поставщик», «Ед. изм», «Кол.», «Масса 1 ед.»)
    и ОВ-шаблон («Позиция», «Код оборудования…», «Завод-изготовитель», «Единица», «Коли-», «Масса единицы»)."""
    def find(*prefixes):
        for pref in prefixes:
            for i, c in enumerate(header_row):
                if (c or '').replace('\n', ' ').strip().startswith(pref):
                    return i
        return None
    return {
        'poz': find('Поз.', 'Позиция'),
        'name': find('Наименование'),
        'type': find('Тип, марка, обозначение', 'Тип, марка'),
        'code': find('Код продукции', 'Код оборудования'),
        'supplier': find('Поставщик', 'Завод'),
        'unit': find('Ед. изм', 'Единица'),
        'qty': find('Кол.', 'Кол-во', 'Коли'),
        'mass': find('Масса 1 ед.', 'Масса'),
        'note': find('Примечание'),
    }

# Рамка чертежа (лист/штамп): «Лист 08/... Изм. Кол.уч. Лист №.док Подп. Дата»,
# «Изм./Подп.», «ГИП», «ГАП», «Разраб.» — не позиции, отбрасываем.
FRAME_RE = re.compile(r'(Лист\s*\d|Лист\s+08|Изм\.|Кол\.уч\.|Подп\.|Дата|ГИП|ГАП|Разраб\.|Статус|Формат)')

def is_frame_row(rec: dict) -> bool:
    blob = ' '.join(v for v in rec.values() if isinstance(v, str))
    if not rec.get('name') and FRAME_RE.search(blob):
        return True
    return False

def extract_records(pdf_path: str):
    doc = pymupdf.open(pdf_path)
    records, report = [], []
    template = None  # 'VK' | 'OV' — по заголовку первой страницы
    for pno, page in enumerate(doc, start=1):
        tabs = page.find_tables()
        if not tabs.tables:
            report.append({'page': pno, 'status': 'NO_TABLES'})
            continue
        table = tabs.tables[0]
        rows = table.extract()
        hdr_idx = next((i for i, r in enumerate(rows)
                        if any((c or '').strip().startswith(('Поз.', 'Позиция')) for c in r)), None)
        if hdr_idx is None:
            report.append({'page': pno, 'status': 'NO_HEADER'})
            continue
        if template is None:
            hdr_cells = ' '.join((c or '') for c in rows[hdr_idx])
            template = 'OV' if 'Позиция' in hdr_cells else 'VK'
        cols = map_columns(rows[hdr_idx])
        missing = [k for k, v in cols.items() if v is None]
        # Согласование с данными: если колонка type/code пустая во всех строках страницы,
        # а следующая за ней непустая и лежит ДО supplier — сдвиг (объединённая шапка
        # на последней странице стр.58 даёт code в [5] при шапке в [4]).
        def _is_real_row(r):
            """Строка данных = есть poz И name не является одиночной цифрой (подзаголовок 1-9)."""
            pi, ni = cols['poz'], cols['name']
            if pi is None or ni is None or pi >= len(r) or ni >= len(r):
                return False
            poz, name = (r[pi] or '').strip(), (r[ni] or '').strip()
            return bool(poz) and not re.fullmatch(r'[\d]{1,2}', name)
        data_rows = [r for r in rows[hdr_idx + 1:] if _is_real_row(r)]
        for k, nxt in (('type', 'code'), ('code', 'supplier')):
            idx = cols.get(k)
            if idx is None:
                continue
            col_vals = [(r[idx] or '').strip() for r in data_rows if idx < len(r)]
            next_vals = [(r[idx + 1] or '').strip() for r in data_rows if idx + 1 < len(r)]
            if not any(col_vals) and any(next_vals):
                cols[k] = idx + 1
                cols[nxt] = None if cols.get(nxt) is None else cols[nxt]
        page_n = 0
        for r in rows[hdr_idx + 1:]:
            rec = {}
            for k, idx in cols.items():
                if idx is None or idx >= len(r):
                    rec[k] = ''
                else:
                    rec[k] = re.sub(r'\s+', ' ', r[idx] or '').strip()
            rec['_page'] = pno
            if is_frame_row(rec):
                report.append({'page': pno, 'status': 'FRAME_SKIPPED', 'poz': rec['poz'][:60]})
                continue
            if not any(rec[k] for k in ('name', 'type', 'qty', 'supplier', 'unit', 'code')):
                report.append({'page': pno, 'status': 'EMPTY_SKIPPED'})
                continue
            records.append(rec)
            page_n += 1
        report.append({'page': pno, 'rows': page_n, 'cols': {k: v for k, v in cols.items()},
                       'missing_cols': missing})
    return records, report, template

# ---------------------------------------------------------------- классификация
def classify(records):
    rows_out, log, prev = [], [], None
    for r in records:
        name = clean_name(r['name'])
        typ = clean_text(r['type'])
        sup = clean_text(r['supplier'])
        note = clean_text(r['note'])
        qty = re.sub(r'\s+', ' ', r['qty']).strip()  # «1 295» — разделитель тысяч, НЕ вырезать пробелы!
        unit = re.sub(r'\s+', ' ', r['unit']).strip()
        # Подзаголовок «1 2 3 4 5 6 7 8 9» — пропускаем
        if re.fullmatch(r'[\d]{1,2}', name):
            continue
        base = {'poz': r['poz'], 'code': clean_text(r['code']), 'mass': r['mass'],
                'supplier': sup, 'type': typ, 'note': note, 'page': r['_page']}
        if not name:
            # Групповая строка: пустое наименование, но есть типоразмер и кол-во —
            # наследуем наименование предыдущей позиции («общее» имя группы строк).
            if typ and qty and prev is not None and prev['role'] == 'item':
                rows_out.append({'role': 'item', 'name': prev['name'], 'unit': unit,
                                 'qty': qty, **base})
                log.append({'type': 'GROUP_INHERIT', 'name': prev['name'][:50],
                            'type': typ, 'qty': qty, 'page': r['_page']})
                prev = rows_out[-1]
                continue
            log.append({'type': 'EMPTY_NAME', 'page': r['_page'], 'raw': r})
            continue
        if qty:
            rows_out.append({'role': 'item', 'name': name, 'unit': unit, 'qty': qty, **base})
            log.append({'type': 'ITEM', 'name': name[:50], 'page': r['_page']})
            prev = rows_out[-1]
            continue
        if is_header(name):
            rows_out.append({'role': 'header', 'name': name, **{k: '' for k in ('unit', 'qty')}, **base})
            log.append({'type': 'HEADER', 'name': name, 'page': r['_page']})
            prev = None  # после раздела групповые строки не наследуются
            continue
        if typ:
            rows_out.append({'role': 'component', 'name': name, 'unit': '', 'qty': '', **base})
            log.append({'type': 'COMPONENT', 'name': name[:50], 'std': typ, 'page': r['_page']})
            prev = rows_out[-1]
            continue
        # continuation
        if prev is not None and prev['role'] in ('item', 'component'):
            prev['name'] += ' ' + name
            log.append({'type': 'MERGE', 'into': prev['name'][:50], 'frag': name[:30], 'page': r['_page']})
        else:
            rows_out.append({'role': 'item', 'name': name, 'unit': unit, 'qty': '', **base})
            log.append({'type': 'ORPHAN', 'frag': name[:30], 'page': r['_page']})
    return rows_out, log

# ---------------------------------------------------------------- QA
def qa(rows_out, log):
    blob = json.dumps(rows_out, ensure_ascii=False)
    blob_l = blob.lower()
    issues = {
        'word_splits': [p for p, _ in SPLITS if p.lower() in blob_l],
        'naked_diam': [r['name'] for r in rows_out if re.search(r'Ø(?!\d)', r['name'])],
        'space_punct': [r['name'] for r in rows_out if re.search(r'[\w]\s[.,:;]', r['name'])],
        'orphans': [l for l in log if l['type'] in ('ORPHAN', 'EMPTY_NAME')],
        'items_no_qty': [r['name'] for r in rows_out if r['role'] == 'item' and not r['qty']],
    }
    # одиночные буквы-фрагменты (кандидаты в SPLITS)
    singles = set()
    for r in rows_out:
        for t in r['name'].split():
            if re.fullmatch(r'[а-яёА-ЯЁ]', t) and t not in 'абв':
                singles.add(t)
    issues['single_letter_tokens'] = sorted(singles)
    return issues

# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pdf')
    ap.add_argument('--out-dir', default='.')
    ap.add_argument('--sep', default=';')
    a = ap.parse_args()

    base = os.path.splitext(os.path.basename(a.pdf))[0]
    os.makedirs(a.out_dir, exist_ok=True)
    csv_path = os.path.join(a.out_dir, f'spec_{base}.csv')
    rows_path = os.path.join(a.out_dir, f'spec_{base}_rows.json')
    log_path = os.path.join(a.out_dir, f'spec_{base}_log.json')

    records, extract_report, doc_template = extract_records(a.pdf)
    rows_out, log = classify(records)
    issues = qa(rows_out, log)

    # Заголовки колонок — как в документе (шаблон определяется автоматически)
    HDR_VK = ['Поз.', 'Наименование и техническая характеристика',
              'Тип, марка, обозначение документа, опросного листа', 'Код продукции',
              'Поставщик', 'Ед. измерения', 'Кол.', 'Масса 1 ед., кг', 'Примечание']
    HDR_OV = ['Позиция', 'Наименование и техническая характеристика',
              'Тип, марка, обозначение документа, опросного листа',
              'Код оборудования, изделия, материала', 'Завод-изготовитель',
              'Единица измерения', 'Количество', 'Масса единицы (кг)', 'Примечание']
    hdr = HDR_OV if doc_template == 'OV' else HDR_VK
    keys = ['poz', 'name', 'type', 'code', 'supplier', 'unit', 'qty', 'mass', 'note']
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=a.sep)
        w.writerow(hdr)
        for r in rows_out:
            if r['role'] == 'header':
                # poz сохраняем, если он есть в документе («Фасонные изделия» 126., 219., 563.)
                w.writerow([r.get('poz', ''), r['name'], '', '', '', '', '', '', ''])
            elif r['role'] == 'component':
                w.writerow(['', r['name'], r['type'], '', r['supplier'], '', '', '', r['note']])
            else:
                w.writerow([r.get(k, '') for k in keys])

    json.dump(rows_out, open(rows_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump({'extract': extract_report, 'log': log, 'issues': issues},
              open(log_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    from collections import Counter
    print(f"PDF:            {a.pdf}")
    print(f"Raw records:    {len(records)}")
    print(f"Final rows:     {len(rows_out)}  {dict(Counter(r['role'] for r in rows_out))}")
    print(f"MERGE:          {sum(1 for l in log if l['type']=='MERGE')}")
    print(f"CSV:            {csv_path}  ({os.path.getsize(csv_path)} bytes)")
    print(f"LOG:            {log_path}")
    print("ISSUES:")
    for k, v in issues.items():
        print(f"  {k}: {v if v else 'OK'}")

if __name__ == '__main__':
    main()
